#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrqncy;
    string dataFilePath;

public:
    ItemTracker() {
        dataFilePath = "frequency.dat";
    }

    void processInputFile ( const string & filePath ) {
        ifstream inputFile ( filePath );
        string item;

        if ( inputFile.is_open() ) {
            while ( getline ( inputFile, item )) {
                itemFrqncy [item] ++;
            }
            inputFile.close();
        }
        else {
            cout << "Error: Unable to open " << filePath << endl;
        }
    }

    void saveDataToFile() {
        ofstream outputFile(dataFilePath);

        if ( outputFile.is_open() ) {
            for ( const auto & pair : itemFrqncy ) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
            cout << "Data saved in " << dataFilePath << endl;
        }
        else {
            cout << "Unable to create output " << dataFilePath << endl;
        }
    }

    void printItemFrqncy() {
        for ( const auto & pair : itemFrqncy ) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void printHistogram() {
        for ( const auto & pair : itemFrqncy ) {
                cout << pair.first << " ";
            for ( int i = 0; i < pair.second; i++ ) {
                cout << "*";
            }
            cout << endl;
        }
    }

    void run() {
        string userInput;
        int choice;

        do {
            cout << "Menu Options:" << endl;
            cout << "1. Look up item frequency" << endl;
            cout << "2. Print frequency list" << endl;
            cout << "3. Print frequency histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch ( choice ) {
            case 1:
                cout << "Enter the item to look up: ";
                cin.ignore();
                getline ( cin, userInput );
                cout << "Frequency of " << userInput << " is: " << itemFrqncy [userInput] << endl;
                break;
            case 2:
                printItemFrqncy();
                break;
            case 3:
                printHistogram();
                break;
            case 4:
                saveDataToFile();
                break;
            default:
                cout << "Invalid choice. Try again. " << endl;
                break;
            }
        } while ( choice != 4 );
    }
};

int main() {
    string inputFile = "CS210_Project_Three_Input_File.txt";
    ItemTracker tracker;
    tracker.processInputFile ( inputFile );
    tracker.run();

    return 0;
}